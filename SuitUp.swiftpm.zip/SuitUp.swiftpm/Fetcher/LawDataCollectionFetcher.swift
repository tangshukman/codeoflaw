import SwiftUI
import SWXMLHash
import Alamofire

//@MainActor
class LawDataCollectionFetcher: ObservableObject {
    @Published var searchResultText = [LawListItem(Favorite: false, ListText: "")]
    @Published var articleElem = [Article.init()]
    @Published var artiCollect = ArticleCollection.init()
    @Published var duplicateYN = false
    @Published var totalPagesCount = 0
    @Published var totalSearchCount = 0
    
    let urlLawString = "https://www.law.go.kr/DRF/lawService.do?OC=tagnshukma&target=law&type=XML"
    
    let urlLawSearchString =  "https://www.law.go.kr/DRF/lawSearch.do?OC=tagnshukma&target=law&type=XML&display=10"
    
    enum FetchError: Error {
        case badRequest
        case badJSON
    }
    
    func saveJSONSearchHistory(data:[String]?) {
        let jsonEncoder = JSONEncoder()
        do {
            let encodedData = try jsonEncoder.encode(data)
            print(String(data: encodedData, encoding: .utf8)!)
            guard let documentDirectoryUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
            
            let fileURL = documentDirectoryUrl.appendingPathComponent("SearchHistory.json")
            do {
                try encodedData.write(to: fileURL)
                print("SearchHistory.json Saved by func.saveJSONSearchHistory")
            }
            catch let error as NSError {
                print(error)
            }
        } catch {
            print(error)
        }
    }
    
    func loadJSONSearchHistory() -> [String]? {
        let jsonDecoder = JSONDecoder()
        do {
            guard let documentDirectoryUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return nil}
            
            let fileURL = documentDirectoryUrl.appendingPathComponent("SearchHistory.json")
            
            let jsonData = try Data(contentsOf: fileURL, options: .mappedIfSafe)
            let decodedJson = try jsonDecoder.decode([String].self, from: jsonData)
            
            print("SearchHistory.json Loaded by func.loadJSONSearchHistory")
            
            return decodedJson
        }
        catch {
            print(error)
            return nil
        }
    }
    
    func saveJSONLawList(data:JSONLawList?) {
        let jsonEncoder = JSONEncoder()
        do {
            let encodedData = try jsonEncoder.encode(data)
            print(String(data: encodedData, encoding: .utf8)!)
            
            guard let documentDirectoryUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
            
            let fileURL = documentDirectoryUrl.appendingPathComponent("lawList.json")
            
            do {
                try encodedData.write(to: fileURL)
                print("lawList.json Saved by func.saveJsonLawList")
            }
            catch let error as NSError {
                print(error)
            }
        } catch {
            print(error)
        }
    }
    
    func loadJSONLawList(completion: @escaping (Bool) -> Void) -> JSONLawList? {
        let jsonDecoder = JSONDecoder()
        do {
            guard let documentDirectoryUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return nil}
            
            let fileURL = documentDirectoryUrl.appendingPathComponent("lawList.json")
            
            let jsonData = try Data(contentsOf: fileURL, options: .mappedIfSafe)
            
            let decodedJsonLawList = try jsonDecoder.decode(JSONLawList.self, from: jsonData)
            
            DispatchQueue.main.async {
                completion(true)
            }
            //print("fetchLawListData done")
            
            print("lawList.json Loaded by func.loadJsonLawList")
            
            return decodedJsonLawList
        }
        catch {
            print(error)
            return nil
        }
    }
    
    func StringTrimming(_ target: String?) -> String? {
        var trimString = target?.replacingOccurrences(of: "\n", with: "", options: NSString.CompareOptions.literal, range: nil)
        trimString = trimString?.replacingOccurrences(of: " ①", with: "①", options: NSString.CompareOptions.literal, range: nil)
        trimString = trimString?.replacingOccurrences(of: "\t", with: " ", options: NSString.CompareOptions.literal, range: nil)
        trimString = trimString?.replacingOccurrences(of: "  ", with: "", options: NSString.CompareOptions.literal, range: nil)
        
        return trimString
    }
    
    //@available(iOS 15.0, *)
    
    func fetchSmall(keyword: String, completion: @escaping (Bool) -> Void) async
    throws{
        print("fetchSmall start")
        let parameters: Parameters = ["LM": keyword]
        AF.request(
            urlLawString,
            method: .get,
            parameters: parameters,
            encoding: URLEncoding.queryString)
        .validate()
        .responseString { response in
            switch response.result {
            case .success:
                let xml = XMLHash.config { config in
                    //config.shouldProcessLazily = true
                }.parse(response.value!)
                
                //print("xml : \(xml)")
                
                var indexnum = 0
                
                var partIndex = 1
                var partString = ""
                
                var chapterIndex = 1
                var chapterString = ""
                
                var sectionIndex = 1
                var sectionString = ""
                
                var subSecIndex = 1
                var subSecString = ""
                //XMLdata stored in Law struct 

                self.articleElem.removeAll()
                ///self.artiCollect.removeAll()
                self.artiCollect = ArticleCollection.init()
                
                self.artiCollect.lawKey?.append(xml["법령"].element?.attribute(by: "법령키")?.text ?? "")
                //print(self.lawArticles[num].lawKey)
                
                self.artiCollect.promulgationDate?.append(xml["법령"]["기본정보"]["공포일자"].element?.text ?? "")
                //print(self.lawArticles[num].promulgationDate!)
                
                self.artiCollect.promulgationNum?.append(xml["법령"]["기본정보"]["공포번호"].element?.text ?? "")
                //print(self.lawArticles[num].promulgationNum!)
                
                self.artiCollect.language?.append(xml["법령"]["기본정보"]["언어"].element?.text ?? "")
                //print(self.lawArticles[num].language!)
                
                self.artiCollect.lawSort?.append(xml["법령"]["기본정보"]["법종구분"].element?.text ?? "")
                //print(self.lawArticles[num].lawSort!)
                
                self.artiCollect.lawSortCord?.append(xml["법령"]["기본정보"]["법종구분"].element?.attribute(by: "법종구분코드")?.text ?? "")
                //print(self.lawArticles[num].lawSortCord!)
                
                self.artiCollect.name?.append(xml["법령"]["기본정보"]["법령명_한글"].element?.text ?? "")
                //print(self.lawArticles[num].lawName!)
                
                self.artiCollect.nameChangeOrNot?.append(xml["법령"]["기본정보"]["제명변경여부"].element?.text ?? "")
                //print(self.lawArticles[num].lawNameChangeOrNot!)
                
                self.artiCollect.lawEnforceDate?.append(xml["법령"]["기본정보"]["시행일자"].element?.text ?? "")
                //print(self.lawArticles[num].lawEffectiveDate!)
                
                self.artiCollect.revision?.append(xml["법령"]["기본정보"]["제개정구분"].element?.text ?? "")
                //print(self.lawArticles[num].revision!)
                
                self.artiCollect.promulgatedOrNot?.append(xml["법령"]["기본정보"]["공포법령여부"].element?.text ?? "")
                //print(self.lawArticles[num].promulgatedOrNot!)
                
                for elem in xml["법령"]["조문"]["조문단위"].all {
                    
                    self.articleElem.append(Article())
                    //print(elem)
                    self.articleElem[indexnum].articleKey?.append(elem.element?.attribute(by: "조문키")?.text ?? "")
                    //print(self.lawArticles[indexnum].articleKey!)
                    
                    self.articleElem[indexnum].articleNum?.append(elem["조문번호"].element?.text ?? "")
                    //print(self.lawArticles[indexnum].articleNum!)
                    
                    self.articleElem[indexnum].articleBranchNum?.append(elem["조문가지번호"].element?.text ?? "")
                    
                    self.articleElem[indexnum].articleOrNot?.append(elem["조문여부"].element?.text ?? "")
                    //print(self.lawArticles[indexnum].articleOrNot!)
                    
                    self.articleElem[indexnum].enforcementDate?.append(elem["조문시행일자"].element?.text ?? "")
                    //print(self.lawArticles[indexnum].articleEnforcementDate!)
                    
                    self.articleElem[indexnum].articleMoveBefore?.append(elem["조문이동이전"].element?.text ?? "")
                    
                    self.articleElem[indexnum].articleMoveAfter?.append(elem["조문이동이후"].element?.text ?? "")
                    
                    let tempPart = "제"+"\(partIndex)"+"편"
                    let tempChapter = "제"+"\(chapterIndex)"+"장"
                    let tempSection = "제"+"\(sectionIndex)"+"절"
                    let tempSubSec = "제"+"\(subSecIndex)"+"관"
                    
                    if (elem["조문여부"].element!.text != "조문"){
                        if let JunMoon = self.StringTrimming(elem["조문내용"].element?.text){
                            
                            if JunMoon.contains(tempPart){
                                partString = JunMoon
                                partIndex += 1
                                chapterString = ""
                                chapterIndex = 1
                                sectionString = ""
                                sectionIndex = 1
                                subSecString = ""
                                subSecIndex = 1
                                
                            }else if JunMoon.contains(tempChapter){
                                chapterString = JunMoon
                                chapterIndex += 1
                                sectionString = ""
                                sectionIndex = 1
                                subSecString = ""
                                subSecIndex = 1
                            }else if JunMoon.contains(tempSection){
                                sectionString = JunMoon
                                sectionIndex += 1
                                subSecString = ""
                                subSecIndex = 1
                            }else if JunMoon.contains(tempSubSec){
                                subSecString = JunMoon
                                subSecIndex += 1
                            }
                            
                            self.articleElem[indexnum].title?.append(JunMoon)
                            //print(self.articleElem[indexnum].title!)
                        }//if let
                    }//if
                    
                    self.articleElem[indexnum].part?.append(partString)
                    self.articleElem[indexnum].chapter?.append(chapterString)
                    self.articleElem[indexnum].section?.append(sectionString)
                    self.articleElem[indexnum].subSection?.append(subSecString)
                    
                    if elem["조문여부"].element!.text == "조문" {
                        
                        let JoNumber = elem["조문번호"].element?.text ?? ""
                        let JoTitle = elem["조문제목"].element?.text ?? ""
                        let JoBranch = elem["조문가지번호"].element?.text ?? ""
                        
                        let JoTitle1 = JoTitle.replacingOccurrences(of: "(", with: "", options: NSString.CompareOptions.literal, range: nil)
                        let JoTitle2 = JoTitle1.replacingOccurrences(of: ")", with: "", options: NSString.CompareOptions.literal, range: nil)
                        
                        let JoTitleComplete = "제" + JoNumber + "조" + "(" + JoTitle2 + ")"
                        let JoTitleComplete2 = "제" + JoNumber + "조의" + JoBranch + "(" + JoTitle2 + ")"
                        
                        let trimTitle = elem["조문내용"].element!.text.replacingOccurrences(of: JoTitleComplete, with: "", options: NSString.CompareOptions.literal, range: nil)
                        
                        let trimBranch = trimTitle.replacingOccurrences(of: JoTitleComplete2, with: "", options: NSString.CompareOptions.literal, range: nil)
                        
                        //let trimJoBody = self.StringTrimming(trimBranch)
                        
                        if JoBranch == ""{
                            self.articleElem[indexnum].title?.append("제" + JoNumber + "조" + " (" + JoTitle2 + ")")
                        } else if JoBranch != ""{
                            self.articleElem[indexnum].title?.append("제" + JoNumber + "조의" + JoBranch + " (" + JoTitle2 + ")")
                        }
                        
                        if JoTitle == "" {self.articleElem[indexnum].title? = ""}
                        
                        if let JoBody = self.StringTrimming(trimBranch) {
                            if JoBody != "" {
                                self.articleElem[indexnum].article?.append(JoBody + "\n\n")
                                self.articleElem[indexnum].articleContent?.append(JoBody)
                            }
                        }
                        
                        if elem["조문내용"].element!.text.contains("삭제"){
                            self.articleElem[indexnum].title = self.StringTrimming(elem["조문내용"].element!.text)
                            self.articleElem[indexnum].article! = ""
                        }
                        
                        for i in 0..<(elem["항"].children.count){
                            
                            if let HangBody = self.StringTrimming(elem["항"][i]["항내용"].element?.text) {
                                self.articleElem[indexnum].article?.append(HangBody+"\n\n")
                                self.articleElem[indexnum].paraNum?.append(elem["항"][i]["항번호"].element?.text ?? "")
                                self.articleElem[indexnum].paraReviSort?.append(elem["항"][i]["항제개정유형"].element?.text ?? "")
                                self.articleElem[indexnum].paraReviString?.append(elem["항"][i]["항제개정일자문자열"].element?.text ?? "")
                                self.articleElem[indexnum].paraContent?.append(HangBody )
                            }
                            
                            for j in 0..<(elem["항"][i]["호"].children.count){
                                
                                if let HoBody = self.StringTrimming(elem["항"][i]["호"][j]["호내용"].element?.text) {
                                    if HoBody != "" {
                                        self.articleElem[indexnum].article?.append("  " + HoBody + "\n\n")
                                        
                                        self.articleElem[indexnum].subParaNum?.append(elem["항"][i]["호"][j]["호번호"].element?.text ?? "")
                                        
                                        self.articleElem[indexnum].subParaContent?.append(HoBody)
                                    }
                                }
                                
                                for k in 0..<(elem["항"][i]["호"][j]["목"].children.count){
                                    
                                    if let MokBody = self.StringTrimming(elem["항"][i]["호"][j]["목"][k]["목내용"].element?.text) {
                                        self.articleElem[indexnum].article?.append("    " + MokBody + "\n\n")
                                        
                                        self.articleElem[indexnum].itemNum?.append(elem["항"][i]["호"][j]["목"][k]["목번호"].element?.text ?? "")
                                        
                                        self.articleElem[indexnum].itemContent?.append(MokBody)
                                    }
                                }//:for_k
                            }//:for_j
                        }//:for_i
                    }
                    
                    self.articleElem[indexnum].name?.append(xml["법령"]["기본정보"]["법령명_한글"].element?.text ?? "")
                    
                    self.articleElem[indexnum].index = indexnum
                    
                    indexnum += 1
                    
                }//:fo
                
                DispatchQueue.main.async {
                    completion(true)
                }
                
                print("fetchSmall done")

                return
                
                //return self.articles.collection
                
            case .failure(let err) :
                print(err.localizedDescription)
                
                return
            }//:switch
        }//response
    }
    
    func fetchLawListData(keyword: String, pages: String, completion: @escaping (Bool) -> Void) async
    throws {
        print("fetchLawListData start")
        let parameters: Parameters = [
            "query": keyword,
            "page": pages
        ]
        
        AF.request(urlLawSearchString,
                   method: .get,
                   parameters: parameters,
                   encoding: URLEncoding.queryString)
        .validate()
        .responseString { response in
            switch response.result {
            case.success:
                
                    let rawData = response.value
                    let xml = XMLHash.config { config in
                        //config.shouldProcessLazily = true
                    }.parse(rawData!)
                    
                    var idx = 0
                    
                let totalCnt = xml["LawSearch"]["totalCnt"].element!.text
                
                self.totalSearchCount = Int(totalCnt)!
                
                if let floatCnt = Float(totalCnt){
                    let ceilCnt = ceilf(floatCnt/10)
                    let intCnt = Int(ceilCnt)
                    self.totalPagesCount = intCnt
                }
                
                self.searchResultText.removeAll()
                for elem in xml["LawSearch"]["law"].all{

                        self.searchResultText.append(LawListItem(Favorite: false, ListText: ""))
                        
                        self.searchResultText[idx].ListText.append(elem["법령명한글"].element?.text ?? "")
                        idx += 1
                    }//:for
                
                DispatchQueue.main.async {
                    completion(true)
                }
                print("fetchLawListData done")
                
                return
            case .failure(let err) :
                print(err.localizedDescription)
            }//:switch
        }
    }//:throws
}
