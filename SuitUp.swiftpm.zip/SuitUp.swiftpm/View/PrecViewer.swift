import SwiftUI

struct PrecViewer: View {
    @Environment(\.colorScheme) var scheme
    @EnvironmentObject var viewFont: fontStyle
    @EnvironmentObject var precFetcher: PrecDataCollectionFetcher
    
    @State var searchText = String()
    @State var rating = 0
    
    @AppStorage("titleColor") var titleColor: Color = Color.primary
    @AppStorage("bodyColor") var bodyColor: Color = Color.primary
    @AppStorage("titleSize", store: .standard) var titleSize = 17 
    @AppStorage("bodySize", store: .standard) var bodySize = 17
    @AppStorage("lineSpace", store: . standard) var lineSpace = 10
    @AppStorage("font") var font: String = UserDefaults.standard.string(forKey: "font") ?? ""
    
    @State var loadedPrecJSON = PrecJSON.init()
    @State var loadedPrecJSONList = PrecJSONList()
    
    @State var showMenu = false
    
    @State var precListIndex = Int()
    
    @State var showHolding = true
    @State var showSummary = true
    @State var showRefArti = true
    @State var showRefPrec = true
    @State var showContents = true
    
    @State var actionTitle = "" 
    
    var body: some View {
        let drag = DragGesture()
            .onEnded {
                if $0.translation.width < -100 {
                    withAnimation {
                        self.showMenu = false
                    }
                }
            }
        
        NavigationView{
            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    Theme.myBackgroundColor(forScheme: scheme)
                        .edgesIgnoringSafeArea(.all)
                    VStack{
                        PrecContentView(loadedPrecJSON: $loadedPrecJSON, loadedPrecJSONList: $loadedPrecJSONList, searchText: $searchText, showHolding: $showHolding, showSummary: $showSummary, showRefArti: $showRefArti, showRefPrec: $showRefPrec, showContents: $showContents, precListIndex: $precListIndex)
                            .frame(width: geometry.size.width-30, height: geometry.size.height)
                            .offset(x: self.showMenu ? 250 : 0)
                            .disabled(self.showMenu ? true : false)
                    }
                    .padding(.horizontal)
                    
                    if self.showMenu {
                        VStack{
                            PrecListView(loadedPrecJSON: $loadedPrecJSON, loadedPrecJSONList: $loadedPrecJSONList, precListIndex: $precListIndex)
                            //.frame(width: geometry.size.width/2)
                                .frame(maxWidth: 250)
                                .transition(.move(edge: .leading))
                            Spacer()
                        }
                    }
                }
                .gesture(drag)
            }
            //:VStack
            .navigationBarTitle(loadedPrecJSON.caseNumber + " " + loadedPrecJSON.caseTitle)
            .searchable(text: $searchText, placement:.navigationBarDrawer(displayMode: SearchFieldPlacement.NavigationBarDrawerDisplayMode.always))
            .navigationBarItems(leading: (
                Button(action: {
                    withAnimation {
                        self.showMenu.toggle()
                    }
                }) {
                    Text("목록")
                    Image(systemName: "line.horizontal.3")
                    //.imageScale(.large)
                }
                    .foregroundColor(.gray)
            ))
        }//:NavigationView
        
        .task {
            guard let tempLoadedPrecJSONList = precFetcher.loadPrecJSONList() else{return}
            loadedPrecJSONList = tempLoadedPrecJSONList
        }//:.task
    }//:bodyview
}//:Struct
