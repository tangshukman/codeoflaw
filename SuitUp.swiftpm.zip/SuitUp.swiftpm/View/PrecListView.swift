import SwiftUI

struct PrecListView: View {
    //@Environment(\.colorScheme) var scheme
    @EnvironmentObject var precFetcher: PrecDataCollectionFetcher
    
    @Binding var loadedPrecJSON: PrecJSON
    @Binding var loadedPrecJSONList: PrecJSONList
    @Binding var precListIndex: Int
    
    @State private var shouldAnimate: Bool = false
    
    var body: some View {
        ScrollView{
            ForEach(loadedPrecJSONList.precList, id:\.caseTitle){prec in
                HStack{
//                    if shouldAnimate {
//                        ActivityIndicator(shouldAnimate:
//                                            self.$shouldAnimate)
//                    }
                    if let number = loadedPrecJSON.caseNumber {
                        if prec.caseNumber == number{
                            Image(systemName: "book")
                                .foregroundColor(Color.white)
                        } else{
                            Image(systemName: "book.closed")
                        }
                    } 
                    Spacer()
                    VStack(alignment: .trailing){
                        Text(prec.caseNumber)
                            .font(.subheadline)
                        Spacer()
                        //Divider()
                        Text(prec.caseTitle)
                            .font(.subheadline)
                    }
                }
                .onTapGesture {
                    self.shouldAnimate = true
                    guard let tempLoadedPrecJSONList = precFetcher.loadPrecJSONList() else{return}
                    loadedPrecJSONList = tempLoadedPrecJSONList
                    for i in 0..<loadedPrecJSONList.precList.count{
                        if loadedPrecJSONList.precList[i].caseTitle == prec.caseTitle {
                            loadedPrecJSON = loadedPrecJSONList.precList[i]
                            precListIndex = i
                        }
                    }
                }
                Divider()
            }
        }.padding()
        //.frame(minHeight: 150, maxHeight: 160, alignment: .leading)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(red: 200/255, green: 200/255, blue: 200/255))
        //.background(scheme == .dark ? Color.black : Color.white)
        
        .task {
            guard let tempLoadedPrecJSONList = precFetcher.loadPrecJSONList() else{return}
            loadedPrecJSONList = tempLoadedPrecJSONList
        }//:.task
    }//bodyview
}//struct
