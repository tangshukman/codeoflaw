import SwiftUI

struct ArticleViewer: View {
    @Environment(\.colorScheme) var scheme
    @EnvironmentObject var viewFont: fontStyle
    @EnvironmentObject var fetcher: LawDataCollectionFetcher
    
    @State private var childPos: CGFloat = 0
    @State private var CGPos = CGPoint()
    
    @State private var offset = CGFloat.zero
    @State private var searchText = String()
    @State var rating = 0
    
    @AppStorage("titleColor") var titleColor: Color = Color.secondary
    @AppStorage("bodyColor") var bodyColor: Color = Color.primary
    @AppStorage("titleSize", store: .standard) var titleSize = 17 
    @AppStorage("bodySize", store: .standard) var bodySize = 17
    @AppStorage("lineSpace", store: .standard) var lineSpace = 5
    @AppStorage("font") var font: String = UserDefaults.standard.string(forKey: "font") ?? ""
    
    @State var loadedJSON = [JSON.init()]
    @State var loadedJSONCollection = JSONCollection()
    @State var loadedJSONLawList = JSONLawList()
    @State var lawListIndex = Int()
    
    @State var showMenu = false
    
    @State private var actionTitle = ""
    @State private var shouldAnimate = false
    
    @State var addressMemo = ""
    @State var addressName = ""
    @State var addressTitle = ""
    @State var addressArticle = ""
    @State var addressKey = ""
    
    @State var memoIsEdit = false
    @FocusState private var isFocused: Bool
    @State var memoText = String()
    @State var bookmarkOnly = false
    
    @State var lastArticleKey = String()
    @State var scrollIdx = [Int]()
    @State var scrollIdxString = [String]()
    
    @State var idx = 1

    func saveAndLoad(){
        loadedJSONCollection.collection = loadedJSON
        loadedJSONLawList.lawList[lawListIndex] = loadedJSONCollection
        fetcher.saveJSONLawList(data: loadedJSONLawList)
        guard let tempLawList = fetcher.loadJSONLawList(completion: { isSuccess in
            if isSuccess {
                self.shouldAnimate = false
            }
        }) else{return}
        loadedJSONLawList = tempLawList
        loadedJSONCollection = loadedJSONLawList.lawList[lawListIndex]
        loadedJSON = loadedJSONCollection.collection
    }
    
    func reAssemble(idx:Int) -> String{
        var assembled = String()
        if idx < 10{
            assembled = "000" + String(idx) + "001"
        }else if 10 <= idx && idx < 100 {
            assembled = "00" + String(idx) + "001"
        }else if 100 <= idx && idx < 1000 {
            assembled = "0" + String(idx) + "001"
        }else{
            assembled = String(idx) + "001"
        }
        return assembled
    }
    
    var searchResults: [JSON] {
        if searchText.isEmpty {
            return loadedJSON
        } else {
            return loadedJSON.filter { $0.title.contains(searchText) || $0.article.contains(searchText)}
        }
    }
    
    var memo: some View{
        Form{
            VStack {
                TextEditor(text: $memoText)
                    .focused($isFocused)
                    .padding(.horizontal)
                    .multilineTextAlignment(.leading)
                    .lineSpacing(0)
                    .frame(maxWidth: .infinity, minHeight:200, maxHeight: 250)
                    .border(Color.gray, width: 2)
                    .foregroundColor(.primary)
                    .background(scheme == .dark ? Color.black : Color.white)
                    .textSelection(.enabled)
                    .cornerRadius(5)
                
                HStack{
                    Button(action: {
                        withAnimation{
                            memoText = ""
                        }
                    }){
                        Text("Clear")
                        
                    }
                    .font(.caption)
                    .foregroundColor(.primary)
                    .buttonStyle(.bordered)
                    .background(.red)
                    .cornerRadius(5)
                    
                    Button(action: {
                        withAnimation{
                            memoText = memoText + addressArticle
                        }
                    }){
                        Text("조문 복사")
                        
                    }
                    .font(.caption)
                    .foregroundColor(.primary)
                    .buttonStyle(.bordered)
                    .background(.gray)
                    .cornerRadius(5)
                    
                    Button(action: {
                        withAnimation{
                            if let i = loadedJSONLawList.lawList.firstIndex(where: {$0.name == addressName}){
                                lawListIndex = i
                                
                                if let j = loadedJSONLawList.lawList[i].collection.firstIndex(where: {$0.title == addressTitle && $0.articleKey == addressKey}){
                                    loadedJSONLawList.lawList[i].collection[j].memo = memoText
                                    print(loadedJSONLawList.lawList[i].collection[j].memo)
                                    
                                    if memoText != ""{
                                        loadedJSONLawList.lawList[i].collection[j].starRank = 1
                                    }
                                }
                            }
                            saveAndLoad()
                            memoIsEdit = false
                            print("memo saved")
                        }
                    }){
                        Image(systemName: "arrow.down.doc")
                        Text("저장")
                    }
                    .font(.caption)
                    .foregroundColor(.primary)
                    .buttonStyle(.bordered)
                    .background(.cyan)
                    .cornerRadius(5)
                    
                    Button(action: {
                        withAnimation{
                            memoIsEdit = false
                        }
                    }){
                        Text("취소")
                    }
                    .font(.caption)
                    .foregroundColor(.primary)
                    .buttonStyle(.bordered)
                    .background(.gray)
                    .cornerRadius(5)
                }
                Spacer()
            }//VStack
            .frame(maxWidth: .infinity, maxHeight: 250)
            .foregroundColor(.gray)
            
        }//Form
        .frame(maxWidth: .infinity, maxHeight: 300)
    }
    
    var ArticleReader: some View {
        //@Binding var scrollidx: Int
        ScrollViewReader{ scrollView in
            ZStack{
                ScrollPositionView(showsIndicators: true, offsetChanged: {
                    print($0)
                }){
                    ForEach(bookmarkOnly ? searchResults.filter{$0.starRank > 0} : searchResults, id:\.index) { articles in
                        HStack{
                            if articles.title != "" || articles.article != ""{
                                VStack(alignment:.leading){
                                    HStack{
                                        Button(action:{
                                            withAnimation{
                                                if articles.starRank == 0 {
                                                    articles.starRank = 1
                                                    
                                                } else if articles.starRank >= 1 {
                                                    articles.starRank = 0
                                                    
                                                }
                                                saveAndLoad()
                                            }
                                        }){
                                            if articles.starRank == 0{
                                                Image(systemName: "bookmark")
                                                    .frame(width:10, height:20)
                                                
                                            } else if articles.starRank >= 1{
                                                Image(systemName: "bookmark.fill")
                                                    .frame(width:10, height:20)
                                                
                                            }//if
                                        }//Button
                                        .buttonStyle(.plain)
                                        //                                            .padding(.horizontal)
                                        
                                        Button(action:{
                                            withAnimation {
                                                memoIsEdit.toggle()
                                                addressName = articles.name
                                                addressTitle = articles.title
                                                addressArticle = articles.article
                                                addressKey = articles.articleKey
                                                addressMemo = articles.memo
                                                memoText = articles.memo
                                                isFocused = true
                                                print(addressName)
                                            }
                                        }
                                        ){
                                            Image(systemName: "note.text")
                                                .frame(width:10, height:20)
                                        }
                                        .padding(.horizontal)
                                        .buttonStyle(.plain)
                                        //Text(" ")
                                    }//hstack
                                    
                                    Group{
                                        HStack{
                                            if articles.title != ""{
                                                Text(articles.title)
                                                    .contextMenu(ContextMenu(menuItems: {
                                                        Button("조문제목 복사", action: {
                                                            UIPasteboard.general.string = articles.title
                                                        })
                                                    }))
                                                    .foregroundColor(titleColor)
                                                    .font(.custom(font, size: CGFloat(titleSize)))
                                                    .padding(.horizontal)
                                                    .overlay(
                                                        RoundedRectangle(cornerRadius: 5)
                                                            .stroke(.secondary, lineWidth: 1)
                                                    )
                                            }
                                            Spacer()
                                        }//hstack
                                        Spacer()
                                        
                                        Text(articles.article)
                                            .contextMenu(ContextMenu(menuItems: {
                                                Button("조문내용 복사", action: {
                                                    UIPasteboard.general.string = articles.title +  articles.article
                                                })
                                            }))
                                            .foregroundColor(bodyColor)
                                            .font(.custom(font, size: CGFloat(bodySize)))
                                    }//group
                                    
                                    if articles.memo != "" {
                                        HStack{
                                            Image(systemName: "arrow.turn.down.right")
                                            Text(articles.memo)
                                                .contextMenu(ContextMenu(menuItems: {
                                                    Button("메모 복사", action: {
                                                        UIPasteboard.general.string = articles.memo
                                                    })
                                                }))
                                                .foregroundColor(bodyColor)
                                                .font(.custom(font, size: CGFloat(bodySize-2)))
                                                .overlay(
                                                    RoundedRectangle(cornerRadius: 5)
                                                        .stroke(.secondary, lineWidth: 1)
                                                )
                                            Spacer()
                                        }//hstack
                                    }//if
                                }//vstack
                                .lineSpacing(CGFloat(lineSpace))
                                .multilineTextAlignment(.leading)
                            }//if
                            Text("  ")
                        }
                        .id(articles.articleKey)
                        Divider()
                    }//:ForEach
                    .padding(.horizontal)
                    .font(.custom(viewFont.font, size: 17))
                }//ScrollView
                //.padding()
                
                Group{
                    VStack {
                        ForEach(scrollIdx, id: \.self) { letter in
                            HStack {
                                Spacer()
                                Button(action: {
                                    withAnimation{
                                        let scrollString = reAssemble(idx: letter)
                                        print("letter = \(letter)")
                                        scrollView.scrollTo(scrollString, anchor: .top)
                                        self.idx = letter
                                        //                                    scrollView.scrollTo("0010001", anchor: .top)
                                    }
                                }, label: {
                                    VStack{
                                        Text("\(letter)  ")
                                            .font(.system(size: 12))
                                            .foregroundColor(.gray)
                                        if letter != scrollIdx.last{
                                            Text("*")
                                        }
                                    }
                                })//button
                            }//hstack
                            //.padding(.horizontal)
                        }//foreach
                    }//Vstack
                }//Group
                
                
                Group{
                    VStack{
                        Spacer()
                        HStack{
                            HStack{
                                Button(action: {
                                    withAnimation{
                                        self.idx -= 50
                                        if self.idx < 1 {self.idx = 1}
                                        scrollView.scrollTo(reAssemble(idx:self.idx), anchor: .top)
                                    }
                                }, label: {
                                    VStack{
                                        Text("-50")
                                            .font(.system(size: 12))
                                    }
                                })
                                .padding(.horizontal)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 5)
                                        .stroke(.secondary, lineWidth: 1)
                                )
                                Button(action: {
                                    withAnimation{
                                        self.idx -= 10
                                        if self.idx < 1 {self.idx = 1}
                                        scrollView.scrollTo(reAssemble(idx:self.idx), anchor: .top)
                                    }
                                }, label: {
                                    VStack{
                                        Text("-10")
                                            .font(.system(size: 12))
                                    }
                                })
                                .padding(.horizontal)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 5)
                                        .stroke(.secondary, lineWidth: 1)
                                )
                            }
                            Spacer()
                            HStack{
                                Button(action: {
                                    withAnimation{
                                        if let maxKey = Int(lastArticleKey.prefix(4)){
                                            self.idx += 10
                                            if self.idx > maxKey {self.idx = maxKey}
                                            scrollView.scrollTo(reAssemble(idx:self.idx), anchor: .top)
                                            
                                        }
                                    }
                                }, label: {
                                    VStack{
                                        Text("+10")
                                            .font(.system(size: 12))
                                            .foregroundColor(.accentColor)
                                    }
                                })
                                .padding(.horizontal)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 5)
                                        .stroke(.secondary, lineWidth: 1)
                                )//.padding(.horizontal)
                                //Divider
                                Button(action: {
                                    withAnimation{
                                        if let maxKey = Int(lastArticleKey.prefix(4)){
                                            self.idx += 50
                                            if self.idx > maxKey {self.idx = maxKey}
                                            scrollView.scrollTo(reAssemble(idx:self.idx), anchor: .top)
                                            
                                        } 
                                    }
                                }, label: {
                                    VStack{
                                        Text("+50")
                                            .font(.system(size: 12))
                                            .foregroundColor(.accentColor)
                                    }
                                    
                                })
                                .buttonStyle(.plain)
                                .padding(.horizontal)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 5)
                                        .stroke(.secondary, lineWidth: 1)
                                )
                            }
                        }//hstack
                    }//vstack
                    .padding()
                }//group
            }//ZStack
            //.padding()
        }//ScrollViewReader
    }
    
    var body: some View {
        let drag = DragGesture()
            .onEnded {
                if $0.translation.width < -100 {
                    withAnimation {
                        self.showMenu = false
                    }
                }
            }
        
        NavigationView{
            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    Theme.myBackgroundColor(forScheme: scheme)
                        .edgesIgnoringSafeArea(.all)
                    
                    if self.memoIsEdit{
                        memo
                            .zIndex(1)
                    }
                    
                    if self.showMenu {
                        VStack{
                            ArticleListView(loadedJSON: $loadedJSON, loadedJSONCollection: $loadedJSONCollection, loadedJSONLawList: $loadedJSONLawList, lawListIndex: $lawListIndex, lastArticleKey: $lastArticleKey, scrollIdx: $scrollIdx, scrollIdxString: $scrollIdxString)
                                .frame(maxWidth: 250)
                                .transition(.move(edge: .leading))
                            Spacer()
                        }
                    }
                    
                    VStack{
                        ArticleReader
                            .frame(width: geometry.size.width, height: geometry.size.height)
                            .offset(x: self.showMenu ? 250 : 0)
                            .disabled(self.showMenu ? true : false)
                    }
                    //.padding(.horizontal)
                }
                .gesture(drag)
            }
            //:VStack
            .navigationBarTitle(loadedJSONCollection.name, displayMode: .inline)
            .navigationBarItems(leading: (
                Button(action: {
                    withAnimation {
                        self.showMenu.toggle()
                    }
                }) {
                    Text("목록")
                    Image(systemName: "line.horizontal.3")
                    //.imageScale(.large)
                }
                    .foregroundColor(.gray)
            ), trailing: (
                Button(action: {
                    withAnimation {
                        bookmarkOnly.toggle()
                    }
                }) {
                    Image(systemName: bookmarkOnly ? "bookmark.fill":"bookmark")
                }
                    .foregroundColor(.gray)
            ))
            .searchable(text: $searchText, placement:.navigationBarDrawer(displayMode: SearchFieldPlacement.NavigationBarDrawerDisplayMode.always)) {
                ForEach(searchResults, id:\.title) { result in
                    Text(result.title).searchCompletion(result.title)
                    //Text(result.article).searchCompletion(result.article)
                }//:ForEach
            }//:searchable
            .onSubmit(of: .search) { // 1
                print("submit")
                //scrollView.scrollTo(searchText)
            }
        }//:NavigationView
        .task {
            guard let tempLoadedJSONLawList = fetcher.loadJSONLawList(completion: { isSuccess in
                if isSuccess {
                    self.shouldAnimate = false
                }
            }) else{return}
            loadedJSONLawList = tempLoadedJSONLawList
        }//:.task
        //.navigationBarTitle(loadedJSONCollection.name)
        
        
    }//:bodyview
}//:Struct

