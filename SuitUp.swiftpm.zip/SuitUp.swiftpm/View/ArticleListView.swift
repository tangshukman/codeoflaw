import SwiftUI

struct ArticleListView: View{
    @Environment(\.colorScheme) var scheme
    @EnvironmentObject var viewFont: fontStyle
    @EnvironmentObject var fetcher: LawDataCollectionFetcher
    
    @Binding var loadedJSON: [JSON]
    @Binding var loadedJSONCollection: JSONCollection
    @Binding var loadedJSONLawList: JSONLawList
    @Binding var lawListIndex: Int
    
    @Binding var lastArticleKey: String
    @Binding var scrollIdx: [Int]
    @Binding var scrollIdxString: [String]
    
    @State private var actionTitle = ""
    @State private var shouldAnimate = false
    
    func scrollIdxCal() {
        let stringKey = lastArticleKey.prefix(4)
        if let intKey = Int(stringKey){
            if intKey > 10{
                scrollIdx = [1, intKey*1/10, intKey*2/10, intKey*3/10, intKey*4/10, intKey*5/10, intKey*6/10, intKey*7/10, intKey*8/10, intKey*9/10, intKey]
                if scrollIdx[0] == scrollIdx[1]{
                    scrollIdx.remove(at: 0)
                }
            }else{
                scrollIdx.removeAll()
                for i in 1...intKey{
                    scrollIdx.append(i)
                }
            }
        }
    }
    
    var body: some View{
        ScrollView{
//            Text("\n\n\n\n")
            ForEach(loadedJSONLawList.lawList, id:\.name){collection in
                HStack{
                    if shouldAnimate {
                        ActivityIndicator(shouldAnimate:
                                            self.$shouldAnimate)
                    }
                    if let name = loadedJSON[0].name {
                        if collection.name == name {
                            Image(systemName: "book")
                                .foregroundColor(Color.white)
                              //  .font(.caption)
                        } else{
                            Image(systemName: "book.closed")
                        }
                    }
                    //Spacer()
                    Text(collection.name)
                        .onTapGesture {
                            self.shouldAnimate = true
                            guard let tempLoadedJSONLawList = fetcher.loadJSONLawList(completion: { isSuccess in
                                if isSuccess {
                                    self.shouldAnimate = false
                                }
                            }) else{return}
                            
                            loadedJSONLawList = tempLoadedJSONLawList
                            
                            if let lawIndex = loadedJSONLawList.lawList.firstIndex(where: {$0.name == collection.name}){
                                loadedJSONCollection = loadedJSONLawList.lawList[lawIndex]
                                lawListIndex = lawIndex
                            }
                            
                            loadedJSON = loadedJSONCollection.collection
                            
                            lastArticleKey = loadedJSON.last?.articleKey ?? ""
                            
                            scrollIdxCal()
                        }
                    Spacer()
                }
                Divider()
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .background(Color(red: 200/255, green: 200/255, blue: 200/255))
        //.edgesIgnoringSafeArea(.all)
        
        .task {
            guard let tempLoadedJSONLawList = fetcher.loadJSONLawList(completion: { isSuccess in
                if isSuccess {
                    self.shouldAnimate = false
                }
            }) else{return}
            loadedJSONLawList = tempLoadedJSONLawList
        }//:.task
    }
}

