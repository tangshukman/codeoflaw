import SwiftUI

struct PrecContentView: View {
    
    @Environment(\.colorScheme) var scheme
    @EnvironmentObject var viewFont: fontStyle
    @EnvironmentObject var precFetcher: PrecDataCollectionFetcher
    
    @AppStorage("titleColor") var titleColor: Color = Color.primary
    @AppStorage("bodyColor") var bodyColor: Color = Color.primary
    @AppStorage("titleSize", store: .standard) var titleSize = 17 
    @AppStorage("bodySize", store: .standard) var bodySize = 17
    @AppStorage("lineSpace", store: . standard) var lineSpace = 10
    @AppStorage("font") var font: String = UserDefaults.standard.string(forKey: "font") ?? ""
    
    @Binding var loadedPrecJSON: PrecJSON
    @Binding var loadedPrecJSONList: PrecJSONList
    
    @Binding var searchText: String
    
    @Binding var showHolding: Bool
    @Binding var showSummary: Bool
    @Binding var showRefArti: Bool
    @Binding var showRefPrec: Bool
    @Binding var showContents: Bool
    
    //@State var lawListIndex = Int()
    @Binding var precListIndex: Int
    
    var body: some View {
        VStack{
            ScrollView(){
                VStack(alignment:.leading){
                    if loadedPrecJSON.caseTitle != ""{
                        Divider()
                        HStack{
                            Image(systemName: "paperclip")
                            StyledText(verbatim: (loadedPrecJSON.caseTitle))
                                .style(.highlight(), ranges:{[$0.range(of: searchText)]})
                                .style(.bold())
                                .foregroundColor(titleColor)
                                .font(.custom(font, size: CGFloat(titleSize)))
                            Spacer()
                        }//HStack
                        
                    }//:VStack
                    
                }//Vstack
                .lineSpacing(CGFloat(lineSpace))
                .multilineTextAlignment(.leading)
                
                VStack(alignment:.leading){
                    Group{
                        Divider()
                        HStack{
                            Image(systemName: "folder")
                            Text("사건번호 :")
                            StyledText(verbatim: loadedPrecJSON.caseNumber)
                                .style(.highlight(), ranges:{[$0.range(of: searchText)]})
                                .style(.bold())
                                .contextMenu(ContextMenu(menuItems: {
                                    Button("Copy", action: {
                                        UIPasteboard.general.string = loadedPrecJSON.caseNumber
                                    })
                                }))
                                .padding(.horizontal)
                            
                        }
                        Divider()
                        HStack{
                            Image(systemName: "folder")
                            Text("판시사항 :")
                            Spacer()
                            Button(action: {
                                withAnimation{
                                    self.showHolding.toggle()
                                }
                            }){
                                Image(systemName: "chevron.forward.circle.fill")
                                    .rotationEffect(.degrees(showHolding ? 90 : 0))
                            }
                        }
                        if showHolding {
                            //Text(loadedPrecJSON.holding)
                            StyledText(verbatim: loadedPrecJSON.holding)
                                .style(.highlight(), ranges:{[$0.range(of: searchText)]})
                                .style(.bold())
                                .contextMenu(ContextMenu(menuItems: {
                                    Button("Copy", action: {
                                        UIPasteboard.general.string = loadedPrecJSON.holding
                                    })
                                }))
                        }
                        
                        Divider()
                        
                        HStack{
                            Image(systemName: "folder")
                            Text("판결요지 :")
                            Spacer()
                            Button(action: {
                                withAnimation{
                                    self.showSummary.toggle()
                                }
                            }){
                                Image(systemName: "chevron.forward.circle.fill")
                                    .rotationEffect(.degrees(showSummary ? 90 : 0))
                            }
                        }
                        if showSummary {
                            //Text(loadedPrecJSON.summary)
                            StyledText(verbatim: loadedPrecJSON.summary)
                                .style(.highlight(), ranges:{[$0.range(of: searchText)]})
                                .style(.bold())
                                .contextMenu(ContextMenu(menuItems: {
                                    Button("Copy", action: {
                                        UIPasteboard.general.string = loadedPrecJSON.summary
                                    })
                                }))
                        }
                        Divider()
                    }
                    
                    Group{
                        HStack{
                            Image(systemName: "folder")
                            Text("참조조문 :")
                            Spacer()
                            Button(action: {
                                withAnimation{
                                    self.showRefArti.toggle()
                                }
                            }){
                                Image(systemName: "chevron.forward.circle.fill")
                                    .rotationEffect(.degrees(showRefArti ? 90 : 0))
                            }
                        }
                        if showRefArti {
                            //Text(loadedPrecJSON.summary)
                            StyledText(verbatim: loadedPrecJSON.refArticle)
                                .style(.highlight(), ranges:{[$0.range(of: searchText)]})
                                .style(.bold())
                                .contextMenu(ContextMenu(menuItems: {
                                    Button("Copy", action: {
                                        UIPasteboard.general.string = loadedPrecJSON.refArticle
                                    })
                                }))
                        }
                        
                        Divider()
                        HStack{
                            Image(systemName: "folder")
                            Text("참조판례 :")
                            Spacer()
                            Button(action: {
                                withAnimation{
                                    self.showRefPrec.toggle()
                                }
                            }){
                                Image(systemName: "chevron.forward.circle.fill")
                                    .rotationEffect(.degrees(showRefPrec ? 90 : 0))
                            }
                        }
                        if showRefPrec {
                            //Text(loadedPrecJSON.summary)
                            StyledText(verbatim: loadedPrecJSON.refPrec)
                                .style(.highlight(), ranges:{[$0.range(of: searchText)]})
                                .style(.bold())
                                .contextMenu(ContextMenu(menuItems: {
                                    Button("Copy", action: {
                                        UIPasteboard.general.string = loadedPrecJSON.refPrec
                                    })
                                }))
                        }
                        
                        Divider()
                        
                        HStack{
                            Image(systemName: "folder")
                            Text("판례내용")
                            Spacer()
                            Button(action: {
                                withAnimation{
                                    self.showContents.toggle()
                                }
                            }){
                                HStack{
                                    Text(showContents ? "" : "더보기")
                                    Image(systemName: "chevron.forward.circle.fill")
                                        .rotationEffect(.degrees(showContents ? 90 : 0))
                                }
                            }
                        }
                        if showContents {
                            StyledText(verbatim: loadedPrecJSON.contents)
                                .style(.highlight(), ranges:{[$0.range(of: searchText)]})
                                .style(.bold())
                                .contextMenu(ContextMenu(menuItems: {
                                    Button("Copy", action: {
                                        UIPasteboard.general.string = loadedPrecJSON.contents
                                    })
                                }))
                        }
                    }
                }
                .foregroundColor(bodyColor)
                .font(.custom(font, size: CGFloat(bodySize)))
                .lineSpacing(CGFloat(lineSpace))
                .multilineTextAlignment(.leading)
                .frame(maxWidth: .infinity, alignment: .bottomLeading)
                //.textSelection(.enabled)
                .font(.custom(viewFont.font, size: 17))
                
            }//ScrollView
            //.textSelection(.enabled)
            
            Divider()
            
        }//:VStack
        //.padding(.horizontal)
        .background(scheme == .dark ? Color.black : Color.white)
        
        .task {
            guard let tempLoadedPrecJSONList = precFetcher.loadPrecJSONList() else{return}
            loadedPrecJSONList = tempLoadedPrecJSONList
        }//:.task
    }//bodyview
}
